#pragma once

#include "datamap_global.h"

class DATAMAP_EXPORT DataMap
{
public:
	DataMap();
};
