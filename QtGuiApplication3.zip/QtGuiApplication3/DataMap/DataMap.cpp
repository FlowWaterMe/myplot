#include "DataMap.h"
#import "c:/program files/common files/system/ado/msado15.dll" no_namespace rename("EOF", "adoEOF")   
DataMap::DataMap()
{
}
